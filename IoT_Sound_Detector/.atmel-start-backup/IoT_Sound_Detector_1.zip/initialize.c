/*
 * initialize.c
 *
 * Created: 03.03.2020 12:54:01
 *  Author: hanso
 */ 

#include "include/driver_init.h"
#include "include/initialize.h"

void initialize(void)
{
	system_init();						// Atmel start driver init
	rtc_init();							// Real time counter
	adc0_init();						// ADC
	io_pin_init();
	fdevopen(CDC_USART_3_write, NULL);	// Initialize standard out
	
	
	sei();								// Enable global interrupts
}


void rtc_init(void)
{
	_PROTECTED_WRITE(CLKCTRL.XOSC32KCTRLA,CLKCTRL_ENABLE_bm);
	RTC.CLKSEL = RTC_CLKSEL_TOSC32K_gc;
	RTC.PER = 3;			// Sampling frequency = 8192
	RTC.CTRLA = RTC_RTCEN_bm;
	EVSYS.CHANNEL0 = EVSYS_GENERATOR_RTC_OVF_gc; /* Real Time Counter overflow */
}


void adc0_init(void)
{
	ADC0.CTRLC = ADC_PRESC_DIV16_gc | ADC_SAMPCAP_bm;
	ADC0.MUXPOS = ADC_MUXPOS_AIN2_gc;
	ADC0.SAMPCTRL = 19;
	ADC0.EVCTRL = ADC_STARTEI_bm;
	ADC0.INTCTRL = ADC_RESRDY_bm;
	ADC0.CTRLA = ADC_ENABLE_bm | ADC_RESSEL_10BIT_gc;

	// Disable digital input buffers on analog input
	PORTD.PIN2CTRL = PORT_ISC_INPUT_DISABLE_gc;

	// Configure ADC0 voltage reference
	VREF.CTRLA = VREF_ADC0REFSEL_2V5_gc;

	// Connect to RTC overflow event
	EVSYS.USERADC0 = EVSYS_CHANNEL_CHANNEL0_gc; /* Asynchronous Event Channel 0 */
}


void io_pin_init(void)
{
	PORTF.DIR |= (1 << PIN5_bp);		// Built-in LED OUTPUT
}



