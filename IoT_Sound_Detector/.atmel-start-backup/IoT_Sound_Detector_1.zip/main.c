
#include "include/initialize.h"
#define F_CPU	(16000000UL / 6)
#include <util/delay.h>
#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "fht/fhtConfig.h"
#include "fht/peak_power.h"

#define MIC_ADC_CHANNEL	2


__flash const uint8_t pattern[] =
{
	0,18,22,19,0,18,22,19,
	0,17,21,18,0,17,21,18,
	0,17,21,18,0,17,21,18,
	15,18,22,16,15,18,22,16,
	15,18,22,16,15,18,22,16,
	15,18,22,19,15,18,22,19,
	15,18,22,19,15,18,22,19,
	11,15,22,18,11,15,22,18,
	11,15,22,18,11,15,22,17,
	11,15,21,16,11,15,21,16,
	15,18,21,16,15,18,21,15,
	18,22,19,15,18,22,19,15,
	18,22,19,15,18,22,19,15,
	18,22,19,0,18,22,19,0,
};


uint16_t number_of_samples = FHT_LEN;
uint8_t record[sizeof(pattern)];
uint8_t r_end;
int16_t fx[FHT_LEN];
volatile uint8_t samples_rdy;
uint8_t print_now = 0;

uint8_t get_main_freq(void);
void record_pattern(void);

// Dixieland beep pattern


int main(void)
{
	initialize();
			
	while (1) 
	{	
		
		record[r_end] = get_main_freq();

		r_end++;
		if (r_end >= sizeof(record))
		{
			r_end = 0;
		}

		// Initialized to zero-count from pattern
		int16_t detection = 70;

		//usart1_put_c(254);
		for (uint8_t p_idx = 0; p_idx < sizeof(record); p_idx++)
		{
			int8_t p = pattern[p_idx];

			uint8_t r_idx = (r_end + 1 + p_idx);	//
			if (r_idx >= sizeof(record))
			{
				r_idx -= sizeof(record);
			}
			int8_t r = record[r_idx];

			uint8_t match_distance = abs(r-p);

			//usart1_put_c(r);

			if (match_distance < 2)
			{
				detection += 2;
			}
			else if (p != 0)
			{
				detection -= 2;
			}
			else
			{
				detection -= 1;
			}
		}
		if (detection > 200)
		{
			//usart1_put_c(255);
			printf("DETECTION\n");
			PORTB.OUTSET = PIN5_bm;
		}
		else
		{
			PORTB.OUTCLR = PIN5_bm;
			printf("%d\n", detection);
		}
		
	}
	
}


ISR(ADC0_RESRDY_vect)
{
	/*
	if (print_now == 1)	// Temporary printing routine. Prints data to terminal, which then can be plotted through a separate Python script
	{
		
		for (uint16_t i = 0; i < number_of_samples; i++)
		{
			printf("%d\n\r", fx[i]);
		}
		print_now = 0;
	}*/

	static uint8_t sample_counter = 0;
	
	// The 10-bit ADC results are subtracted 512 to be centered around 0, giving it a range of [-512, 512]
	// It is then scaled by a factor of 32 giving it a range of [-16384, 16384]
	// This is a requirement from the FHT algorithm
	
	//fx[sample_counter] = (ADC0.RES-512)*32;
	fx[sample_counter] = (ADC0.RES-669) *32;
	
	
	// Report batch ready and hold off sampling for
	// three batch periods
	if (sample_counter == number_of_samples)
	{
		print_now = 1;
		samples_rdy  = 1;
		RTC.PER      = (128*4) * 3 - 1;
	}

	// Resume sampling after hold-off
	if (sample_counter == 0)
	{
		RTC.PER = 3;
	}
	
	// Update sample counter
	sample_counter++;
	sample_counter %= (number_of_samples + 1);
}


uint8_t get_main_freq(void)
{
	while(!samples_rdy);
	samples_rdy=0;

	fhtDitInt(fx);
	return get_peak_power_bin(fx);
}


void record_pattern(void)
{
	uint8_t freq_bin;
	printf("Recording..");
	
	for (uint8_t i = 0; i < 112; i++)
	{
		freq_bin = get_main_freq();
		printf("%d\n\r", freq_bin);
	}
	printf("Done recording\n\r");
}