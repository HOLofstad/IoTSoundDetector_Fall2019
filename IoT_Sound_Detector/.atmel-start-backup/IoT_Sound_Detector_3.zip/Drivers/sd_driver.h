/*
 * sd_driver.h
 *
 * Created: 02.09.2020 16:19:40
 *  Author: hanso
 */ 


#ifndef SD_DRIVER_H_
#define SD_DRIVER_H_

#include <stdint.h>

void sd_init();

void sd_send_dummy_bytes(uint16_t n_bytes);

void sd_cs_enable();

void sd_cs_disable();

//sd_write(offset, data);

//sd_read(offset, read_length);

//sd_erase(offset, erase_length);

//sd_file_list();    // Returns a list of available files on SD-card.

// A proper struct to describe file structure in storage



#endif /* SD_DRIVER_H_ */