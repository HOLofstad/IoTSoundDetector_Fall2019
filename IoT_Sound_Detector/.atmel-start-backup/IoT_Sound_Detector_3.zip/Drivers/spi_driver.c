/*
 * spi_driver.c
 *
 * Created: 17.09.2020 16:33:23
 *  Author: hanso
 */ 
#include <stdint.h>
#include <avr/io.h>

uint8_t spi_exchange_byte(uint8_t data)
{
	if ((SPI0.CTRLA & SPI_MASTER_bm) != SPI_MASTER_bm)
	{
		printf("NOT IN MASTER MODE!!\n\r");
	}
	
	SPI0.DATA = data;
	while(SPI0.INTFLAGS & SPI_IF_bm);	// While data is transmitting
	
	uint8_t return_data = SPI0.DATA;
	return return_data;	
}


