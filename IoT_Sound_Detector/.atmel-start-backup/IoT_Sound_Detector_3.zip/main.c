
#include "include/initialize.h"
#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>
#include "fht/fhtConfig.h"
#include "fht/peak_power.h"
#include "usart_basic.h"
#include "drivers/sd_driver.h"
#include "drivers/spi_driver.h"

#define MIC_ADC_CHANNEL	2


__flash const uint8_t pattern[] = 
{
	15, 15, 15, 15, 15, 11, 11, 11,
	15, 19, 19, 19, 19, 19, 19, 18,
	18, 18, 19, 19, 19, 19, 15, 15,
	15, 19, 23, 23, 23, 23, 23, 23,
	23, 22, 22, 23, 23, 23, 23, 23,
	23, 22, 22, 20, 20, 20, 20, 20,
	20, 20, 19, 19, 17, 17, 20, 20,
	19, 19, 17, 17, 15, 15, 15, 0,
	0, 0, 0, 0, 0, 15, 15, 15,
	15, 11, 11, 11, 15, 15, 19, 19,
	19, 19, 19, 19, 18, 18, 19, 19,
	19, 19, 15, 15, 15, 15, 19, 23,
	23, 23, 23, 23, 23, 22, 22, 23,
	23, 23, 23, 23, 23, 23, 22, 22
};

uint16_t number_of_samples = FHT_LEN;
uint8_t record[sizeof(pattern)];
uint8_t r_end;
int16_t fx[FHT_LEN];
volatile uint8_t samples_rdy;
int16_t detection;
uint8_t enable_sampling = 0;


uint8_t get_main_freq(void);
void record_pattern(void);


int main(void)
{
	initialize();
			
	while (1) 
	{		
		
		sd_init();
		
					
		//record_pattern();
		while(1);
		
		/*enable_sampling = 1;
		
		record[r_end] = get_main_freq();
		
		r_end++;
		if (r_end >= sizeof(record))
		{
			r_end = 0;
		}
		
		for (uint8_t offset = 0; offset < sizeof(record); offset++)
		{
			detection = 0;
			
			for (uint8_t p_idx = 0; p_idx < sizeof(record); p_idx++)
			{
				int8_t p = pattern[p_idx];

				uint8_t r_idx = (offset + 1 + p_idx);
				if (r_idx >= sizeof(record))
				{
					r_idx -= sizeof(record);
				}
				int8_t r = record[r_idx]; 

				uint8_t match_distance = abs(r-p);

				if (match_distance < 2)		// The FHT is very accurate, so why is the match distance threshold equal to 2?
				{							// This would then imply a frequency span of 195.3 Hz, instead of the original bin width of 65.1 Hz. Should reduce this to 0, and test functionality.
					detection += 2;			
				}
				else if (p != 0)		// Maybe this should be removed?
				{
					detection -= 2;		// Subtracts 2 if there is silence. Some patterns may contain silence, so this is unfortunate
				}
				else
				{
					detection -= 1;
				}
			}
			
			if (detection >= -100)		// The detection threshold will vary between different patterns. This needs to be automated somehow. 
			{
				printf("PATTERN DETECTED!\n\r");
				PORTF.OUTCLR = PIN5_bm;
				while(1);
			} 
			else
			{
				PORTF.OUTSET = PIN5_bm;
			}
		}		*/
	}
}


ISR(TCA0_OVF_vect)
{
	TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
	ADC0.COMMAND = 1;	// Start ADC conversion
}


ISR(ADC0_RESRDY_vect)
{		
	if (enable_sampling)
	{
		static uint8_t sample_counter = 0;
		
		// The 10-bit ADC results are subtracted 669 to be centered around 0.
		// It is then scaled by a factor of 32 giving it a maximum range of [-16384, 16384]
		// This is a requirement from the FHT algorithm
		
		fx[sample_counter] = (ADC0.RES-669) * 32;
		
		// Report batch ready and hold off sampling for 0.1 seconds
		if (sample_counter == number_of_samples)
		{
			samples_rdy  = 1;
			TCA0.SINGLE.PER = 12500;	// Wait 0.1 seconds
		}
		
		// Resume sampling after hold-off
		if (sample_counter == 0)
		{
			TCA0.SINGLE.PER = 15;
		}
		
		// Update sample counter
		sample_counter++;
		sample_counter %= (number_of_samples + 1);
	}
	else
	{
		uint8_t adc_res  = ADC0.RES;
		if (adc_res > 200)	// Tweak this threshold if microphone gain is modified
		{
			enable_sampling = 1;
		}
	}
	
	
}


uint8_t get_main_freq(void)
{
	while(!samples_rdy);	
	
	samples_rdy=0;
	
	fhtDitInt(fx);
	return get_peak_power_bin(fx);
}


void record_pattern(void)
{
	uint8_t freq_bin;
	uint8_t row_count = 0;
	printf("Recording..\n\r");
	
	for (uint8_t i = 0; i < 112; i++)
	{
		freq_bin = get_main_freq();
		row_count++;
		if (row_count == 8)
		{
			printf("%d,\n\r", freq_bin);
			row_count = 0;
		}
		else
		{
			printf("%d, ", freq_bin);	
		}		
	}
	printf("Done recording\n\r");
}