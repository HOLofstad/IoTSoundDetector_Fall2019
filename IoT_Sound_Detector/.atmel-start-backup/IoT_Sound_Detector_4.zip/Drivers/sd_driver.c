/*
 * sd_driver.c
 *
 * Created: 16.09.2020 18:57:02
 *  Author: hanso
 */ 

#include "../drivers/spi_driver.h"
#include "sd_driver.h"
#include <stdio.h>
#include <avr/io.h>
#include <stdint.h>

#define DUMMY_BYTE 0xFF

uint8_t CMD0[6] = {0x40, 0x00, 0x00, 0x00, 0x00, 0b10010101}; // Last byte is CRC (I think it is unnecessary to specify a value, could probably be 0xFF)

void sd_init()
{
	uint8_t success = 0;
	uint8_t return_data[2];
	
	printf("Initializing SD-card\n\r");
	
	sd_cs_disable();
	sd_send_dummy_bytes(10); 
	sd_cs_enable();
	
	while (!success)
	{
		spi_exchange_byte(0x40);
		spi_exchange_byte(0x00);
		spi_exchange_byte(0x00);
		spi_exchange_byte(0x00);
		spi_exchange_byte(0x00);
		spi_exchange_byte(0b10010101);
		
		/*for (uint8_t i = 0; i < sizeof(return_data); i++)
		{
			if (return_data[i] == 0x01)
			{
				success = 1;
			}
		}*/
		success = 1; // This should be if(return_data == expected_value) --> success = 1
	}
	
	return_data[0] = spi_exchange_byte(DUMMY_BYTE);
	return_data[1] = spi_exchange_byte(DUMMY_BYTE);
	
	for (uint8_t j = 0; j < sizeof(return_data); j++)
	{
		printf("Read results: %d \n\r", return_data[j]);
	}
}

void sd_send_dummy_bytes(uint16_t n_bytes)
{
	for (uint8_t i = 0; i < n_bytes; i++)
	{
		spi_exchange_byte(DUMMY_BYTE);
	}
}

void sd_cs_enable()
{
	PORTC.DIR |= (1 << 6);	// SD-module SPI chip select pin as output
	PORTC.OUT &= !(1 << 6);	// Pull CS pin low to enable chip	
}

void sd_cs_disable()
{
	PORTC.DIR |= (1 << 6);	// SD-module SPI chip select pin as output
	PORTC.OUT |= (1 << 6);	// Pull CS pin low to enable chip
}