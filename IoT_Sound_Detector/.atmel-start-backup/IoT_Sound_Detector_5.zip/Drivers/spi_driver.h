/*
 * spi_driver.h
 *
 * Created: 17.09.2020 16:54:09
 *  Author: hanso
 */ 


#ifndef SPI_DRIVER_H_
#define SPI_DRIVER_H_

#include <stdint.h>

uint8_t spi_exchange_byte(uint8_t data);


#endif /* SPI_DRIVER_H_ */