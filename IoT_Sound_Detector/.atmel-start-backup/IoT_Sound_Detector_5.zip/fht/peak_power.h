/*
 * peak_power.h
 *
 * Created: 22.05.2018 16:09:25
 *  Author: M44001
 */


#ifndef PEAK_POWER_H_
#define PEAK_POWER_H_

uint8_t get_peak_power_bin(int16_t *fx);



#endif /* PEAK_POWER_H_ */